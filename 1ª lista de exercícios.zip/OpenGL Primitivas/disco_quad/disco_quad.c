#include <GL/glew.h>
#include <GL/freeglut.h>

//nesse programa a figura, desde as linhas até os quadrados, é desenhada por completo desde o início, mas as linhas só aparecem depois da tecla c ser pressionada devido ao uso de GL_FILL e GL_LINE na função desenhaMinhaCena que garantem q tudo seja preenchido com cores sólidas e depois seja traçado por cima as linhas

int linhas = 0; //inicializamos a variável global com 0

void desenha(){
    //coordenadas
    glBegin(GL_TRIANGLE_STRIP);
    glVertex3f(5, 5, 0);
	glVertex3f(20,20,0);
    glVertex3f(80, 5, 0);
	glVertex3f(65,20,0);
    glVertex3f(80, 80, 0);
	glVertex3f(65,65,0);
    glVertex3f(5, 80, 0);
	glVertex3f(20,65,0);
	glVertex3f(5, 5, 0);
	glVertex3f(20,20,0);
    glEnd();
}
void desenhaMinhaCena(void)
{
    glClear(GL_COLOR_BUFFER_BIT);

    glColor3f(1, 1, 1);
    glPolygonMode( GL_FRONT_AND_BACK, GL_FILL); //GL_FILL garante que será preenchido todo o polígono  
    desenha();

    if(linhas == 1){
	    glColor3f(0, 0, 0);
	    glPolygonMode( GL_FRONT_AND_BACK, GL_LINE); //GL_LINE garante q apenas linhas serão desenhadas 
	    desenha();
    }
    
    glFlush();
}

void teclaPressionada(unsigned char key, int x, int y)
{
   switch(key)
   {
      case 27: //se o usuário pressionar esc a janela fecha
        exit(0); break;
      case 'c': //se o usuário digitar a tecla c ou C a variável global linhas muda de estado
	    if(linhas == 0) //se o estado atual for 0 então muda para 1 e as linhas aparecem
		    linhas = 1;
	    else
		    linhas = 0; break; //se o estado atual for 1 então muda para 0 e as linhas somem
      case 'C':
	    if(linhas == 0)
		    linhas = 1;
	    else
		    linhas = 0; break;
      default: break;
   }
   //redesenha a tela
   glutPostRedisplay();
}

void inicializa(void)
{

    glClearColor(0, 0, 0, 0); //cor do fundo da janela   
}

void redimensiona(int w, int h)
{
   glViewport(0, 0, w, h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(0, 85, 0, 85, -1, 1);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

int main(int argc, char **argv)
{
    // acordando o GLUT
    glutInit(&argc, argv);

    // definindo a versão do OpenGL que vamos usar
    glutInitContextVersion(1, 1);
    glutInitContextProfile(GLUT_COMPATIBILITY_PROFILE);

    // configuração inicial da janela do GLUT
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(85, 85);

    // abre a janela
    glutCreateWindow("Disco quadrado");

    // registra callbacks para alguns eventos
    glutDisplayFunc(desenhaMinhaCena);
    glutReshapeFunc(redimensiona);
    glutKeyboardFunc(teclaPressionada);
    
    inicializa();

    // entra em loop e nunca sai
    glutMainLoop();
    return 0;
}
