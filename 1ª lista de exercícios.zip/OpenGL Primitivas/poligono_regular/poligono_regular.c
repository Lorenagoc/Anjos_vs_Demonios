#include<GL/glew.h>
#include<GL/freeglut.h>
#include<math.h>

#define raio 20 //raio do polígono

int NUM_LADOS = 4; //inicia com um quadrado

void desenhaCirculo()
{

    float t;
    int i;

    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0,1,0);
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); //polígono será desenhado sem preenchimento
    glBegin(GL_POLYGON);
    
    for(i=0; i<=NUM_LADOS; i++)
    {
        t = ((2 * M_PI *i) / NUM_LADOS);
        glVertex3f(50 + cos(t) * raio, 50 + sin(t) * raio, 0);
    }
    
    glEnd();
    
    glFlush(); //manda para a janela o q irei desenhar

}

void teclaPressionada(unsigned char key, int x, int y)
{
    
    switch(key)
    {
        case 27: //se o usuário pressiona ESC a janela fecha
            exit(0); break;
        case '+': //se o usuário pressiona + o numero de lados do polígono aumenta
            NUM_LADOS++; break;
        case '-': //se o usuário pressiona + o numero de lados do polígono diminui
            NUM_LADOS--; break;
        default: break;
    }    
    
    glutPostRedisplay();
    
}

void redimensiona(int w, int h)
{
    glViewport(0,0,w,h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0,100,0,100,-1,1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void inicializa(void)
{
    glClearColor(1,1,1,0);
}

int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    
    glutInitContextVersion(1,1);
    glutInitContextProfile(GLUT_COMPATIBILITY_PROFILE);
    
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
    glutInitWindowSize(500,500);
    glutInitWindowPosition(100,100);
    
    glutCreateWindow("Poligono Regular");
    glClearColor(1,1,1,0);
    
    glutDisplayFunc(desenhaCirculo);
    glutReshapeFunc(redimensiona);
    glutKeyboardFunc(teclaPressionada);
    
    inicializa();
    
    glutMainLoop();
    return 0;
}
